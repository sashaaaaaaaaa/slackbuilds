# [List of deprecated symbols](https://developer.gnome.org/gtk2/2.24/api-index-deprecated.html)

#### [gtk_tree_view_column_get_cell_renderers, function in GtkTreeViewColumn](https://developer.gnome.org/gtk2/2.24/GtkTreeViewColumn.html#gtk-tree-view-column-get-cell-renderers)

* pynicotine/gtkgui/settingswindow.py: renderers = cols[1].get_cell_renderers()
* pynicotine/gtkgui/settingswindow.py: renderers = cols[1].get_cell_renderers()
* pynicotine/gtkgui/settingswindow.py: renderers = cols[1].get_cell_renderers()
* pynicotine/gtkgui/settingswindow.py: renderers = cols[0].get_cell_renderers()
* pynicotine/gtkgui/settingswindow.py: renderers = column.get_cell_renderers()
* pynicotine/gtkgui/settingswindow.py: renderers = cols[0].get_cell_renderers()
* pynicotine/gtkgui/settingswindow.py: renderers = cols[1].get_cell_renderers()
* pynicotine/gtkgui/userlist.py: for render in self.col_trusted.get_cell_renderers():
* pynicotine/gtkgui/userlist.py: for render in self.col_notify.get_cell_renderers():
* pynicotine/gtkgui/userlist.py: for render in self.col_privileged.get_cell_renderers():
* pynicotine/gtkgui/userlist.py: renderers = self.col_comments.get_cell_renderers()
* pynicotine/gtkgui/frame.py: for r in c.get_cell_renderers():
* pynicotine/gtkgui/frame.py: for r in c.get_cell_renderers():
* pynicotine/gtkgui/transferlist.py: self.col_percent.set_attributes(self.col_percent.get_cell_renderers()[0], value=4, visible=14)

#### [gtk_menu_append, macro in GtkMenu](https://developer.gnome.org/gtk2/2.24/GtkMenu.html#gtk-menu-append)

* pynicotine/gtkgui/utils.py: used in PopupMenu(gtk.Menu)
* pynicotine/gtkgui/utils.py: used in PressHeader
