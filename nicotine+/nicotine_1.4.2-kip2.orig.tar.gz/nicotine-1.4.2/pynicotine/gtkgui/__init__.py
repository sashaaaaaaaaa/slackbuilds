# Copyright (C) 2003-2004 Hyriand <hyriand@thegraveyard.org>
pass
